package it.unibo.apice.oop.p12exceptions.safedevices;

/**
 * @author mirko
 * 
 */
public class ExitCommandException extends Exception {
}
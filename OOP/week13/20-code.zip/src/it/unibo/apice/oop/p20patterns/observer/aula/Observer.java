package it.unibo.apice.oop.p20patterns.observer.aula;

public interface Observer {
    
    void notifyStringInserted(String s);

}

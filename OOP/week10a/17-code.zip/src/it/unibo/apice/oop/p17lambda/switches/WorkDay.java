package it.unibo.apice.oop.p17lambda.switches;

public enum WorkDay {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY
}

package it.unibo.apice.oop.p20patterns.observer.auladone;

public interface Observer {
    
    void valueInserted(String s);

}

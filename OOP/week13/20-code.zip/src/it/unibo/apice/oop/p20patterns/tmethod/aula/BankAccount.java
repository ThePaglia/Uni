package it.unibo.apice.oop.p20patterns.tmethod.aula;

public interface BankAccount {
	
    void withdraw(int n);
	
}

package it.unibo.apice.oop.p15gui.gui;

public interface UserInterface {
	
	void show();
	
	void setDimensions(int x, int y);
}

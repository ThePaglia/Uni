package it.unibo.apice.oop.p17lambda.first;

import java.util.*;

public class MethodReferences {
	
	private static int staticMyCompare(final String a, final String b) {
		return a.compareTo(b);
	}
	private int instanceMyCompare(final String a, final String b) {
		return b.compareTo(a);
	}
	public static void main(String[] args) {
		final List<String> list = List.of("a", "bb", "c", "ddd");
		final MethodReferences objAL = new MethodReferences();

		Collections.sort(list, (x,y) -> staticMyCompare(x,y));
		Collections.sort(list, MethodReferences::staticMyCompare);  // same as above
		System.out.println(list); // [a, bb, c, ddd]

		Collections.sort(list, (x,y) -> objAL.instanceMyCompare(x, y));
		Collections.sort(list, objAL::instanceMyCompare);  // same as above
		System.out.println(list); // [ddd, c, bb, a]
		
		Collections.sort(list, (x,y) -> x.compareTo(y));
		Collections.sort(list, String::compareTo);  // same as above
		System.out.println(list); // [ddd, c, bb, a]
	}
}

package com.example.http

import org.koin.dsl.module

val appModule = module {
}

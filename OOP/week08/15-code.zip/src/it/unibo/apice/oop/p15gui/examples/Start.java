package it.unibo.apice.oop.p15gui.examples;

import javax.swing.*;

public class Start {
	public static void main(String[] args){
		// Creo il frame e imposto titolo e altre proprietà
		JFrame frame = new JFrame();	   
		frame.setTitle("Prova di JFrame"); 
		frame.setSize(320,240);
		frame.setVisible(true);
		frame.setSize(320,241);
	}
}

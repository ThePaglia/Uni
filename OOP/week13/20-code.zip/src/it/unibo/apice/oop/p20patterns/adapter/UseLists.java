package it.unibo.apice.oop.p20patterns.adapter;

import java.util.Arrays;
import java.util.List;

public class UseLists {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10,20,30,40,50);

	}

}

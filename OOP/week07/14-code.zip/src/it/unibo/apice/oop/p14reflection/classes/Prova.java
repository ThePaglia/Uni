package it.unibo.apice.oop.p14reflection.classes;

public class Prova {
	public String ilMioMetodo(){ 
		return "Riuscito!!";
	}
}

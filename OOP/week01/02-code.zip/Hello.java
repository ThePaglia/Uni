// This class necessarily goes into a file Hello.java
class Hello{
  public static void main(String[] args){
    System.out.println("Hello World!");
  }
}
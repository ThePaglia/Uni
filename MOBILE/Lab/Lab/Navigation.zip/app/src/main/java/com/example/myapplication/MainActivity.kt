package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.AppBar
import com.example.myapplication.ui.Screen1
import com.example.myapplication.ui.Screen2
import com.example.myapplication.ui.Screen3
import com.example.myapplication.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    Scaffold(
                        topBar = { AppBar(navController) },
                    ) { contentPadding ->
                        NavGraph(navController, modifier = Modifier.padding(contentPadding))
                    }
                }
            }
        }
    }
}

sealed class NavigationRoute(
    val route: String
) {
    data object Screen1 : NavigationRoute("screen1")
    data object Screen2 : NavigationRoute("screen2")
    data object Screen3 : NavigationRoute("screen3")
}

@Composable
fun NavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = NavigationRoute.Screen1.route,
        modifier
    ) {
        with(NavigationRoute.Screen1) {
            composable(route) {
                Screen1(navController)
            }
        }
        with(NavigationRoute.Screen2) {
            composable(route) {
                Screen2(navController)
            }
        }
        with(NavigationRoute.Screen3) {
            composable(route) {
                Screen3(navController)
            }
        }
    }
}

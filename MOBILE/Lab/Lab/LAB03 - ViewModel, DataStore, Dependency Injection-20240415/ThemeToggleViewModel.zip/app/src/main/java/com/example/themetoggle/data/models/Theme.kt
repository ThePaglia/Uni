package com.example.themetoggle.data.models

enum class Theme { Light, Dark, System }

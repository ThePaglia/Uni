package it.unibo.apice.oop.p15gui.mvc.model;

public class AttemptsLimitReachedException extends Exception {

    public AttemptsLimitReachedException() {}
}

package it.unibo.apice.oop.p06interfaces.domo;

public class Test {

	public static void main(String[] args) {
		
		Device d;

	}

}

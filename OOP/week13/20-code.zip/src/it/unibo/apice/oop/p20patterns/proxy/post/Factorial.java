package it.unibo.apice.oop.p20patterns.proxy.post;

public interface Factorial {
	
	int factorial(int i);
}

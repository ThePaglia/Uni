package it.unibo.apice.oop.p12exceptions.safedevices;

/**
 * @author mirko
 *
 */
public class CommandNotRecognisedException extends Exception{
    
	public CommandNotRecognisedException(String s){
		super(s);
	}
} 
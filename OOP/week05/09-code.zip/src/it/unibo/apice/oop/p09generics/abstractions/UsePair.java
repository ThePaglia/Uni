package it.unibo.apice.oop.p09generics.abstractions;

public class UsePair {

	public static void main(String[] args) {
		
	}

}

package it.unibo.apice.oop.p15gui.mvc.model;

public enum DrawResult {
	YOURS_IS_LOWER, YOURS_IS_HIGHER, YOU_WON;
}

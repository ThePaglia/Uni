package it.unibo.apice.oop.p20patterns.singleton;

public class UseLog {
	public static void main(String[] s){
		Log.getLog().add("Prova 1");
		Log.getLog().add("Prova 2");
	}
}

package it.unibo.apice.oop.p20patterns.tmethod;

public interface OperationFeeStrategy {
	
	int operationFee(int n);

}

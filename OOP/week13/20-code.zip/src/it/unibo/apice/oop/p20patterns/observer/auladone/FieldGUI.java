package it.unibo.apice.oop.p20patterns.observer.auladone;

public interface FieldGUI {
    
    void addObserver(Observer obs);

}

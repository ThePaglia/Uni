package it.unibo.apice.oop.p12exceptions.classes;

public class Prova {
	
	public static int f(int i){ return f(i);}

	public static void main(String[] args) {
		Object o = null;
		System.out.println(o.toString());

	}

}

package it.unibo.apice.oop.p20patterns.decorator;

public class Funghi extends BasicIngredient {
	
	public Funghi(Pizza p){
		super("AbstractIngredient",100,p);
	}	
}

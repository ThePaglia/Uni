package com.example.traveldiary.data.repositories

import com.example.traveldiary.data.database.Place
import com.example.traveldiary.data.database.PlacesDAO
import kotlinx.coroutines.flow.Flow

class PlacesRepository(private val placesDAO: PlacesDAO) {
    val places: Flow<List<Place>> = placesDAO.getAll()

    suspend fun upsert(place: Place) = placesDAO.upsert(place)

    suspend fun delete(place: Place) = placesDAO.delete(place)
}

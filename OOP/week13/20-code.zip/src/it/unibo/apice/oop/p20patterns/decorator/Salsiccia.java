package it.unibo.apice.oop.p20patterns.decorator;

public class Salsiccia extends BasicIngredient {
	
	public Salsiccia(Pizza p){
		super("Salsiccia",150,p);
	}	
}

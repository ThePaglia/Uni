package it.unibo.apice.oop.p09generics.abstractions;

public class UseList{
    public static void main(String[] s){
    	

    }
} 